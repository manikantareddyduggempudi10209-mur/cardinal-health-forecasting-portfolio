
import pandas as pd
import numpy as np
from pathlib import Path
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_percentage_error
import joblib
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
MODELS = ROOT / "models"
FIGS = ROOT / "reports" / "figures"
PROCESSED.mkdir(parents=True, exist_ok=True)
MODELS.mkdir(parents=True, exist_ok=True)
FIGS.mkdir(parents=True, exist_ok=True)

def load_data():
    orders = pd.read_csv(RAW / "orders.csv", parse_dates=["week_end"])
    usage = pd.read_csv(RAW / "usage.csv", parse_dates=["week_end"])
    supplier = pd.read_csv(RAW / "supplier_schedule.csv", parse_dates=["week_end"])
    df = orders.merge(usage, on=["week_end","sku"]).merge(supplier, on=["week_end","sku","lead_time_weeks"])
    df = df.sort_values(["sku","week_end"]).reset_index(drop=True)
    return df

def feature_engineering(df):
    def add_feats(g):
        g = g.sort_values("week_end").copy()
        g["orders_lag1"] = g["orders"].shift(1)
        g["orders_rm3"] = g["orders"].rolling(3).mean()
        g["week"] = g["week_end"].dt.isocalendar().week.astype(int)
        g["month"] = g["week_end"].dt.month
        return g
    df = df.groupby("sku", group_keys=False).apply(add_feats)
    df["season_sin"] = np.sin(2*np.pi*df["week"]/52)
    df["season_cos"] = np.cos(2*np.pi*df["week"]/52)
    df = df.dropna().reset_index(drop=True)
    return df

def train_and_eval(df):
    feats = ["orders_lag1","orders_rm3","lead_time_weeks","week","month","season_sin","season_cos","units_used"]
    X = df[feats]
    y = df["orders"]
    # Simple time-based split
    split = int(len(df)*0.8)
    X_train, X_test = X.iloc[:split], X.iloc[split:]
    y_train, y_test = y.iloc[:split], y.iloc[split:]
    model = RandomForestRegressor(n_estimators=200, random_state=42)
    model.fit(X_train, y_train)
    preds = model.predict(X_test)
    rmse = mean_squared_error(y_test, preds, squared=False)
    mape = mean_absolute_percentage_error(y_test, preds)
    print(f"RMSE: {rmse:.2f}")
    print(f"MAPE: {mape:.3f}")
    # Save
    joblib.dump(model, MODELS / "model.pkl")
    # Plot
    fig = plt.figure()
    plt.plot(y_test.values, label="actual")
    plt.plot(preds, label="predicted")
    plt.legend()
    plt.title("Test Set — Actual vs Predicted")
    fig.tight_layout()
    fig.savefig(FIGS / "actual_vs_predicted.png", dpi=160)
    # Save processed features
    df.to_csv(PROCESSED / "features.csv", index=False)

if __name__ == "__main__":
    df = load_data()
    df = feature_engineering(df)
    train_and_eval(df)
