# Dashboards

Place your Power BI/Tableau exports here. Suggested views:
- Forecast vs Actual by SKU/Week
- Stockout risk heatmap
- Safety stock and reorder point diagnostics
