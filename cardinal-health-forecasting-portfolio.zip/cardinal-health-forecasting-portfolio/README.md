# Healthcare Demand Forecasting — Cardinal Health (Portfolio Project)

> **Problem:** Frequent stockouts and excess inventory caused higher costs and delayed deliveries.  
> **Solution:** An end-to-end demand forecasting pipeline that integrates multiple sources (supplier schedules, order history, usage trends) and predicts weekly demand to drive procurement decisions.  
> **Impact:** ↓ Stockouts **28%**, ↓ Excess **19%**, ≈ **$8.25M** savings in 90 days (portfolio scenario).

---

## 🧱 Repository Structure
```
cardinal-health-forecasting-portfolio/
├── src/                    # Reusable pipeline code (ETL, features, training, forecasting)
├── notebooks/              # Exploratory & storytelling notebooks
├── data/
│   ├── raw/                # Sample/synthetic input data
│   └── processed/          # Outputs from ETL/feature steps (gitignored)
├── models/                 # Serialized models (gitignored)
├── dashboards/             # BI artifacts (images / PDFs / links)
├── reports/figures/        # Charts exported from notebooks
├── infra/adf_pipelines/    # Azure Data Factory pipeline JSON (sample)
└── .github/workflows/      # CI formatting/lint checks
```

> ⚠️ **Note:** All data included here is **synthetic** and safe to share publicly.

---

## 🚀 Quickstart
```bash
# 1) Create a virtual environment (optional)
python -m venv .venv && source .venv/bin/activate  # (Windows: .venv\Scripts\activate)

# 2) Install dependencies
pip install -r requirements.txt

# 3) Run the minimal pipeline on synthetic data
python src/train_model.py

# 4) See outputs
ls models/            # model.pkl
ls data/processed/    # feature tables
```

---

## 🧪 What This Demo Shows
- Clean ETL: from `data/raw/` → `data/processed/`
- Feature engineering: rolling demand, lead times, seasonality proxies
- Baseline ML model (RandomForest) with basic metrics (RMSE, MAPE)
- Saved artifacts: `models/model.pkl`, `reports/figures/`
- How this maps to **Databricks + Azure Data Factory** in production

---

## 🛠️ Tech Stack
- **Python**: pandas, scikit-learn, matplotlib
- **Data Factory** (sample JSON): `infra/adf_pipelines/`
- **Power BI/Tableau**: export screenshots in `dashboards/` (placeholders)

---

## 🗺️ Architecture (Portfolio View)
1. **Ingest** order history, supplier schedules, and consumption/usage trends
2. **Transform** and align time grains (weekly) and entities (SKU/Location)
3. **Engineer** features (rolling means, lags, lead-time, seasonality)
4. **Train** and evaluate baseline model(s) (RandomForest, XGBoost, etc.)
5. **Forecast** next period(s) and push results to BI layer

---

## 📈 Results (Portfolio Scenario)
- **Stockouts:** -28%
- **Excess inventory:** -19%
- **Savings:** ~\$8.25M in 90 days

These figures represent an illustrative scenario for portfolio purposes.

---

## 🔒 Data & Privacy
All datasets here are **synthetic** and generated for demonstration only.

---

## 🤝 Contributing
PRs welcome for better baselines, new features, or deployment recipes.

---

## 📬 Contact
**Manikanta Reddy** — Irving, TX — `manikantareddyduggempudi10209@gmail.com`
